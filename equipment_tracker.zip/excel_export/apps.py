from django.apps import AppConfig


class ExcelExportConfig(AppConfig):
    name = 'excel_export'
