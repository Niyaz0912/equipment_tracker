from django.apps import AppConfig


class EquipmentsConfig(AppConfig):
    name = 'equipments'
