# Создаем README.md
Equipment Tracker 🖥️

Система учета компьютерного оборудования по материальным ценностям (МЦ).

## 🚀 Возможности

- 📊 Учет оборудования с МЦ номерами
- 👥 Управление сотрудниками и отделами
- 🔍 Поиск по МЦ, сотрудникам, типам оборудования
- 📝 История выдачи оборудования
- 📁 Импорт/экспорт данных в Excel
- 🎯 Фильтрация по статусам, типам, отделам
- 📱 Адаптивный интерфейс (Bootstrap 5)

## 🛠 Технологии

- Python 3.13
- Django 6.0
- SQLite
- Bootstrap 5
- Pandas (для работы с Excel)

## 📦 Установка

1. Клонировать репозиторий:
```bash
git clone https://github.com/Niyaz0912/equipment_tracker.git
cd equipment_tracker

2. Создать виртуальное окружение:
python -m venv venv
# Windows:
venv\Scripts\activate
# Linux/Mac:
source venv/bin/activate

3. Установить зависимости:
pip install -r requirements.txt

4. Применить миграции:
python manage.py migrate

5. Создать суперпользователя:
python manage.py createsuperuser

6. Запустить сервер:
python manage.py runserver

7. Открыть в браузере:

🌐 Приложение: http://127.0.0.1:8000/

⚙️ Админка: http://127.0.0.1:8000/admin/

📁 Фикстуры данных
В папке fixtures/ содержатся готовые данные для быстрого старта:

Файл	            Записи  	     Размер 	    Описание
all_data.json	    Все данные	     249 KB	        Полный дамп всей системы
employees.json	    67	             16 KB	        Отделы и сотрудники
equipments.json	    243	             100 KB	        Оборудование с МЦ номерами
auth.json	        41	             7 KB	        Пользователи и группы
contenttypes.json	10	             1 KB	        Типы контента Django
history.json	    0	             1 KB	        История выдачи (пустая)

Кодировка: Все файлы сохранены в UTF-8.

📊 Импорт/Экспорт данных
Импорт из Excel:
Перейти: http://localhost:8000/equipment/import/

Скачать шаблон Excel

Заполнить данные по образцу

Загрузить файл

Экспорт в Excel:
Нажать кнопку "Экспорт" в навигационной панели

Файл сохранит текущие фильтры

Формат: Excel (.xlsx)

🏗️ Структура проекта
text
equipment_tracker/
├── config/              # Настройки Django
├── equipments/         # Приложение для оборудования
├── employees/          # Приложение для сотрудников  
├── history/            # Приложение для истории выдачи
├── fixtures/           # 📁 Готовые данные (фикстуры)
├── templates/          # Шаблоны (Bootstrap 5)
├── static/             # Статические файлы
├── media/              # Загружаемые файлы
├── import_export/      # Excel файлы для импорта/экспорта
├── requirements.txt    # Зависимости Python
├── manage.py           # Управление Django
└── README.md           # Эта документация

🔧 Основные команды
bash
# Создать резервную копию данных
python manage.py dumpdata --indent 2 > backup_$(date +%Y%m%d_%H%M%S).json

# Загрузить конкретную фикстуру
python manage.py loaddata fixtures/employees.json
python manage.py loaddata fixtures/equipments.json

# Создать новые миграции
python manage.py makemigrations

# Проверить состояние базы данных
python manage.py check
🎯 Особенности реализации
Гибкое закрепление оборудования:

За сотрудником 👤

За отделом 🏢

Не закреплено

Умный поиск:

По МЦ номеру
По сотруднику (фамилия, имя)
По типу оборудования
По отделу

Фильтрация:
По статусу (На складе, Выдано, Сломан и т.д.)
По типу (Ноутбук, Компьютер, Принтер и т.д.)
По отделу сотрудника
По закрепленному отделу

📱 Основные страницы
Страница	URL	Описание
📋 Оборудование	/equipment/	Список всего оборудования с фильтрами
👥 Сотрудники	/employees/	Список сотрудников по отделам
🔍 Поиск	/equipment/search/	Поиск оборудования
📤 Импорт	/equipment/import/	Импорт из Excel
⚙️ Админка	/admin/	Полный CRUD через Django Admin